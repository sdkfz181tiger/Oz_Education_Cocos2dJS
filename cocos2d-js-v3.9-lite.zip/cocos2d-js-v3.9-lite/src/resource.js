var res = {
	background_640x960:"res/background_640x960.png",
	background_score:"res/background_score.png",
	player_png:"res/player.png",
	spike_png:"res/spike.png",
	title_gameover:"res/title_gameover.png",
	cat_base_0:"res/cat_base_0.png",
	cat_fall_0:"res/cat_fall_0.png",
	cat_jump_c_0:"res/cat_jump_c_0.png",
	cat_jump_s_0:"res/cat_jump_s_0.png",
	cat_jump_s_1:"res/cat_jump_s_1.png",
	cat_jump_s_2:"res/cat_jump_s_2.png",
	cat_jump_s_3:"res/cat_jump_s_3.png",
	cat_jump_s_4:"res/cat_jump_s_4.png",
	tx_game_education_01_plist:"res/tx_game_education_01.plist",
	tx_game_education_01:"res/tx_game_education_01.png"
};

var g_resources = [];
for (var i in res){
	g_resources.push(res[i]);
}